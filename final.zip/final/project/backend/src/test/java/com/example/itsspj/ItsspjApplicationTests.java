package com.example.itsspj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItsspjApplicationTests {

    @Test
    void contextLoads() {
    }

}
