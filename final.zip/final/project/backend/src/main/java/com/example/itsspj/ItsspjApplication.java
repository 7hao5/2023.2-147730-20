package com.example.itsspj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItsspjApplication {

    public static void main(String[] args) {
        SpringApplication.run(ItsspjApplication.class, args);
    }

}
